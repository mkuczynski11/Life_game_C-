#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <time.h>
#include <algorithm>
#include <fstream>
using namespace std;

#define IMIE "Martin"
#define NAZWISKO "Kuczynski"
#define INDEKS 180199

#define ILOSC_WILKOW 5
#define ILOSC_ZOLWI 5
#define ILOSC_OWIEC 5
#define ILOSC_LISOW 5
#define ILOSC_CYBEROWIEC 5
#define ILOSC_ANTYLOP 5
#define ILOSC_TRAWY 3
#define ILOSC_MLECZY 3
#define ILOSC_GUARANY 3
#define ILOSC_WILCZYCHJAGOD 3
#define ILOSC_BARSZCZUSOSNOWSKIEGO 3